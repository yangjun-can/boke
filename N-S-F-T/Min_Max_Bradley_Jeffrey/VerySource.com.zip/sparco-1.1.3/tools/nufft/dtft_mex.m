 function X = dtft_mex(varargin)

disp('This dtft_mex.m is a dummy m-file that is included to provide')
disp('a reminder that you must have the Mex file "dtft_mex.mex???" that')
disp('is appropriate for your system.  For pc-linux (32bit), the mex file is')
disp('called "dtft_mex.mexglx", which is provided in the "mex" subdirectory.')
disp('For a mac, it is ".mexmac" and for a sun, it is "dtft_mex.mexsol", which')
disp('may or may not be provided.  If you have another OS, then you may')
disp('be out of luck, or you may be able to cajole Jeff into compiling a')
disp('mex file for your OS, except for Windoze.')
error 'no appropriate mex file!?'
