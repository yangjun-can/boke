function str = fieldname(name)
%
% Use by: parseParams, getOption
%

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id$

str = strrep(name,'-','_');
str = strrep(str,' ','_');
