function op = opTranspose(op)
% OPTRANSPOSE   Transpose operator
%
%    OPTRANSPOSE(OP) creates an operator that is the the adjoint
%    operator OP.

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: opTranspose.m 577 2007-09-17 01:48:28Z mpf $

op = @(x,mode) opTranspose_intrnl(op,x,mode);


function y = opTranspose_intrnl(op,x,mode)
if mode == 0
  info = op([],0);
  y = {info{2},info{1},info{3}([3,4,1,2]),{'Transpose',op}};
elseif mode == 1
  y = op(x,2);
else
  y = op(x,1);
end
