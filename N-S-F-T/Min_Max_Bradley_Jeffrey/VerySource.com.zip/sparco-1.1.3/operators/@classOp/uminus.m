function A = uminus(A)

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: uminus.m 699 2008-01-12 16:51:54Z mpf $

A.sign = -A.sign;

