function result = ctranspose(A)

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: ctranspose.m 699 2008-01-12 16:51:54Z mpf $

A.adjoint = xor(A.adjoint,1);
result = A;

