function resetMatvec(A)

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: resetMatvec.m 699 2008-01-12 16:51:54Z mpf $

global classOp_nAx;
global classOp_nATx;

classOp_nAx  = 0;
classOp_nATx = 0;
