function op = opMask(A)
% OPMASK  Selection mask
%
%    OPMASK(A) creates an operator that computes the dot-product of
%    a given vector with the (binary) mask provided by A. If A is a
%    matrix it will be vectorized prior to use.
%
%    See also opColRestrict, opRestriction.

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: opMask.m 577 2007-09-17 01:48:28Z mpf $

op = @(x,mode) opMask_intrnl(A,x,mode);


function y = opMask_intrnl(A,x,mode)
if mode == 0
   m = size(A,1);
   n = size(A,2);
   c =~isreal(A);
   y = {m*n,m*n,[c,1,c,1],{'Mask'}};
else
   y = A(:) .* x;
end
