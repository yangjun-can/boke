function op = opHaar(n,levels)
%OPHAAR   One-dimensional Haar wavelet
%
%   OPHAAR(N,LEVELS) creates a Haar wavelet operator for one
%   dimensional signal of length N. LEVELS indicates the number of
%   scales to use, default is 5.
%
%   See also opWavelet

%   Copyright 2007, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: opHaar.m 577 2007-09-17 01:48:28Z mpf $

if (nargin < 2), levels = 5; end

op = opWavelet(n,1,'haar',0, levels,'min');
