using FastTransforms, LinearAlgebra, Test

include("specialfunctionstests.jl")
include("chebyshevtests.jl")
include("quadraturetests.jl")
include("libfasttransformstests.jl")
include("nuffttests.jl")
include("fftBigFloattests.jl")
include("paduatests.jl")
include("gaunttests.jl")
include("hermitetests.jl")
include("toeplitztests.jl")
include("clenshawtests.jl")
