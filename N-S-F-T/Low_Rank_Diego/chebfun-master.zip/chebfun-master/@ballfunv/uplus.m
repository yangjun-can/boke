function f = uplus(f)
%+  BALLFUNV unary plus.
%   +F of a BALLFUNV is F.
%
%   G = UPLUS(F) is called for the syntax '+F'.

% Copyright 2019 by The University of Oxford and The Chebfun Developers.
% See http://www.chebfun.org/ for Chebfun information.

% Nothing to do here.
end
