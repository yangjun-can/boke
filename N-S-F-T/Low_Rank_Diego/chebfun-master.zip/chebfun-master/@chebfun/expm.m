% EXPM computes the exponential of a linear operator.
% See chebop/expm.
