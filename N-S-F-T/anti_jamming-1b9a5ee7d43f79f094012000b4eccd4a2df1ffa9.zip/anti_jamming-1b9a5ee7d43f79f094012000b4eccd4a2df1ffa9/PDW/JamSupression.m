function y = JamSupression(sig,N,type,fADC)
switch type
    case 2
        lg_sig = log(sig);
        Rx = real(lg_sig);
        Ix = imag(lg_sig);
        base = Ix(1);
        for i = 2:N
            if Ix(i)>base+pi
                Ix(i) = Ix(i)-2*pi;
            else
                if Ix(i)<base-pi
                    Ix(i) = Ix(i)+2*pi;
                end
            end
        end
        A_ = exp(mean(Rx));
        J = A_*exp(1j*(Ix));
        y = sig - J;
        
    case 1
        lg_sig = sig;
        FT_sig = fft(sig);
        [peaks,ind] = findpeaks(abs(FT_sig),'minpeakheight',60);
        max_space = 0;
        dis = diff(ind);
        if dis(1)>dis(end)
            w_est = ind(1);
        else
            w_est = ind(end);
        end
        FT_sig(w_est-3:w_est+3) = 0;
        y = ifft(FT_sig);
        return
%         FFT_N = 2^(ceil(log2(length(sig)))+1);
%         FFT_N = 750;
%         FT_log_sig = fftshift(abs(fft(lg_sig,FFT_N)));
%         fAxis = linspace(-fADC/2,fADC/2,FFT_N);
%         base = FFT_N/2+1;
%         FT_right = FT_log_sig(base:end);
%         [~,index] = max(FT_right);
%         W_ = fAxis(base+index-1);
%         W_2 = W_;
%         threshold = 1.5e6;
%         while (abs(W_2-W_)<threshold)
%             FT_right(index) = 0;
%             FT_log_sig(base+index-1-10:base+index-1+10) = 0;
%             [~,index] = max(FT_right);
%             W_2 = fAxis(base+index-1);
%         end
%         %return 
%         for i = 1:length(sig)
%             re_j(i) = abs(sig(i))*exp(1j*2*pi*W_*(i-1)/fADC);
%         end
%         y = sig-re_j;
%         if W_2<W_
%             Wstop=2*(W_-threshold)/fADC;
%             wp=Wstop;ws=2*W_/fADC;rp=0.1;rs=60;   %DFָ�꣨��ͨ�˲�����ͨ������߽�Ƶ��
%             [N,wp]=ellipord(wp,ws,rp,rs); %����ellipord������ԲDF����N��ͨ����ֹƵ��wp
%             [b,a]=ellip(N,rp,rs,wp);
% 
%             y=filter(b,a,y);
%         else
%             Wpass = 2*(W_+threshold)/fADC;
%             wp = Wpass;ws = 2*W_/fADC;rp=0.1;rs=60;   %DFָ�꣨��ͨ�˲�����ͨ������߽�Ƶ��
%             [N,wp]=ellipord(wp,ws,rp,rs);    %����ellipord������ԲDF����N��ͨ����ֹƵ��wp
%             [b,a]=ellip(N,rp,rs,wp,'high'); %����ellip������Բ��ͨDFϵͳ����ϵ������B��A
%             y = filter(b,a,y);
%         end            
%         y = mapminmax(real(y),-1,1);
end


